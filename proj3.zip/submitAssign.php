<?php
include_once("db_connect.php");

//Get all the fields filled in the form

// $inum = $_POST[];

// print"<h1>Enter addAthlete.php</h1>";
// print"<h1>type: $type</h1>";
// print"<h1>size: $eq_size</h1>";
// print"<h1>color: $color</h1>";
// print"<h1>brand: $brand</h1>";
// print"<h1>model: $model</h1>";
// print"<h1>lock num: $lock_num</h1>";

//generate the query

// $query= "INSERT INTO athlete(inum) VALUES ("

//send the query to the data base;
$result=$db->query($query);

if($result != FALSE)
{
  print "<p>Sucessfully added $type into equipment table </p>";
}
?>