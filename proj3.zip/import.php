<?php
include_once("db_connect.php");
print($db);

?>


