Hannah, Tony, Jeb

proj2/hw5

Who did what:
-addEquipment.html, addEquipment.php - Tony
-admin_dash.html, create tables - Jeb
-index.html, combine admin_dash.html & addEquipment functionality (+ styling for addEquipment functionality in admin_dash) - Hannah
-timeline & functionalities - all (see cs360_hw5.pdf)

Links:
-Link to general landing page: http://www.cs.gettysburg.edu/~seabha01/cs360/Dashboard_LP_Scripts/home.html

-Link to admin dashboard: http://www.cs.gettysburg.edu/~seabha01/cs360/Dashboard_LP_Scripts/admin_dash.html

-Link to 1st functionality: http://www.cs.gettysburg.edu/~seabha01/cs360/Dashboard_LP_Scripts/addEquipment.html
----> alternately, you can toggle the "add" button on the admin dashboard to test this functionality